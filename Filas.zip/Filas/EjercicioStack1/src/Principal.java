import javax.swing.*;

public class Principal {
    public static void main(String[] args) throws Exception { //psvm
        Pila data = new Pila();


        data.push("Elemento 1");
        data.push("Elemento 2");
        data.push("Elemento 3");
        data.push("Elemento 4");
        data.push("Elemento 5");
        System.out.println("Pila: \n"+data.toString());
        String eliminado = data.pop();


        JOptionPane.showMessageDialog(null, "Elemento eliminado: "+eliminado);
        System.out.println("Pila: \n"+data.toString());


        JOptionPane.showMessageDialog(null, "Elemento en la cima: "+data.cima());

    }

}
