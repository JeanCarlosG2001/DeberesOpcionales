import java.util.Stack;


public class Pila {
    private Stack<String> coleccion;

    //constructor
    public Pila(){
        coleccion=new Stack<String>();
    }
    //metodos
    public void insertar(String dato){
        coleccion.push(dato);
    }

    //metodos
    public String extraer(){
        return coleccion.pop();
    }

    //metodos
    public String cima(){
        return coleccion.peek();
    }

    //metodos
    @Override
    public String toString() {
        StringBuilder lista=new StringBuilder();
        for(int i=coleccion.size()-1; i>=0; i--){
            lista.append(coleccion.get(i)+"\n");
        }
        return lista.toString();
    }

    //metodos
    public  int side(){
        return coleccion.size();
    }

    //metodos
    public boolean esVacia(){
        if (coleccion.isEmpty()){
            return true;
        }else{
            return false;
        }
    }

}
