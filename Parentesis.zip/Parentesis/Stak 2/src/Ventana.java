import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel principal;
    private JTextArea txtCodigo;
    private JButton btnComprobar;

    public Ventana() {
        btnComprobar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Pila pilas= new Pila();
                String texto = txtCodigo.getText();

                // Verificar si hay algún paréntesis, llave o corchete
                boolean haySimbolos = texto.matches(".*[\\[\\]{}()].*");// Busca cualquier paréntesis, llave o corchete, las * son para que se busque en todo el texto
                if (!haySimbolos) {
                    JOptionPane.showMessageDialog(null, "No hay paréntesis, llaves o corchetes para validar");
                    return;
                }

                // Verificar si los paréntesis, llaves o corchetes están balanceados
                for (int i = 0; i < texto.length(); i++) {
                    char letra = texto.charAt(i);
                    if (letra == '(' || letra == '{' || letra == '[') {
                        pilas.insertar(String.valueOf(letra));
                    } else if (letra == ')' || letra == '}' || letra == ']') {
                        if (pilas.esVacia()) {
                            JOptionPane.showMessageDialog(null, "Error: Hay un cierre sin apertura");
                            return;
                        }
                        
                        char salida = pilas.extraer().charAt(0);
                        if ((letra == ')' && salida != '(') ||
                            (letra == '}' && salida != '{') ||
                            (letra == ']' && salida != '[')) {
                            JOptionPane.showMessageDialog(null, "Error: Los símbolos no coinciden");
                            return;
                        }
                    }
                }


                // Mostrar el resultado
                if (pilas.esVacia()) {
                    JOptionPane.showMessageDialog(null, "Correcto: Los paréntesis están balanceados");
                } else {
                    JOptionPane.showMessageDialog(null, "Error: Hay aperturas sin cierre");
                }
            }
        });
    }


    // Programa principal
    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
