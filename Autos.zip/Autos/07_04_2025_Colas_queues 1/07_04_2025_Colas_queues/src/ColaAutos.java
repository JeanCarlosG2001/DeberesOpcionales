import java.util.LinkedList;
import java.util.Queue;

public class ColaAutos {

    //atributos
    private Queue<Auto> listaAutos; //genera una cola

    //constructor
    public ColaAutos(){
        listaAutos = new LinkedList<Auto>();
    }

    //metodos

    //metodo encolar
    public void encolar(Auto dato){
        listaAutos.add(dato); //encolar

    }

    //metodo desencolar
    //devuelvo una clase/ objeto
    //thorws Exception para manejo de errores
    public Auto desencolar() throws Exception{
        if(listaAutos.isEmpty())
            throw new Exception("Ya no existen autos encolados");
        return  listaAutos.poll();
    }

    //metodo frente
    //devuelvo una clase/ objeto
    //thorws Exception para manejo de errores
    public Auto frente() throws Exception{
        if(listaAutos.isEmpty())
            throw new Exception("Ya no existen autos encolados");
        return  listaAutos.peek();
    }

    //metodo listar
    public String listarTodos(){
        //generar un StringBuilder
        StringBuilder sb=new StringBuilder();
        //recorrer la coleccion
        for (Auto a1:listaAutos){
            //a1 es un auto
            //a1.toString();
            sb.append(a1.toString());
        }
        return sb.toString(); //devuelvo el string
    }
}

