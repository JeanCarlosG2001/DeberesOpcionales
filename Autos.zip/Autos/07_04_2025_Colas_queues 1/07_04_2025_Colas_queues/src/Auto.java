/*
Jean Carlos Gomez
Deber por cada año que el auto tenga, pagar 50$, hacer una multiplicacion del año del carro
info sale del ultimo año atendido*/

public class Auto {
    //generar atributos

    private String marca;
    private int anio;
    private int anoActual=2025;

    //constructor
    public Auto(String marca, int anio) {
        this.marca = marca;
        this.anio = anio;
    }
    //generar getters y setters
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    //metodo para calcular el pago
    public double calcularPago() {
        return (this.anoActual-this.anio)*50;
    }

    //metodo toString
    @Override
    public String toString() {
        return "\n---Auto---\n" + "Marca: "+marca + "\t Año: "+anio + "\tPago de impuesto: $" + calcularPago();
    }
}
