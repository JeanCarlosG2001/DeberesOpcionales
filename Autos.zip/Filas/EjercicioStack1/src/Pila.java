import java.util.Stack;

//Clase Pila
public class Pila {
    private Stack<String> colecccion;

    //Constructor
    public Pila() {
        colecccion = new Stack<String>();
    }

    //Metodos
    public void push(String dato) throws Exception {
        if (colecccion.size() >= 10) {
            throw new Exception("La pila ha alcanzado su límite máximo de 10 elementos");
        }
        colecccion.push(dato);
    }

    //Metodo
    public String pop() throws Exception{

        if (colecccion.empty()) {
            throw new Exception("Pila vacia");
        }
        return colecccion.pop();
    }


    //Metodo
    public String cima() throws Exception{
      /*  if (colecccion.empty()) {
            throw new Exception("Pila vacia");
        }*/ //deber
        return colecccion.peek();
    }

    //Metodo
    @Override
    public String toString() {

        StringBuilder listado = new  StringBuilder();
        for(int i = colecccion.size()-1;i>=0;i--) {
            listado.append(colecccion.get(i)+"\n");

    }
        return listado.toString();
    }
}