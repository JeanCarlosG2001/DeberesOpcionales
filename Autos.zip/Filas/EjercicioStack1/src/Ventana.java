import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//Clase Ventana
public class Ventana {
    private JPanel principal;
    private JTextField textTexto;
    private JButton btnPush;
    private JButton lblPop;
    private JTextArea txtMostrar;
    private JLabel lblTexto;
    private Pila data = new Pila();


    //Constructor
    public Ventana() {

        //Accion de los botones
        btnPush.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    data.push(textTexto.getText());
                    txtMostrar.setText(data.toString());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        //Accion de los botones
        lblPop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String eliminado = data.pop();//Elimina el elemento de la pila
                    JOptionPane.showMessageDialog(null, "Elemento eliminado: " + eliminado);//Muestra el elemento eliminado
                    txtMostrar.setText(data.toString());//Actualiza la pila
                }catch (Exception ex){//Manejo de la excepcion
                    JOptionPane.showMessageDialog(null, "La pila esta vacia");}//Muestra el mensaje de error
            }
        });
    }

    //Metodo main
    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
